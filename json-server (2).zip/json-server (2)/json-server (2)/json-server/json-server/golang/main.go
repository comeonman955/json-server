package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var db *mongo.Database

// Connect to MongoDB
func connectToMongoDB() {
	uri := "mongodb://127.0.0.1:27017"

	client, err := mongo.NewClient(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal("Error creating MongoDB client:", err)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	err = client.Connect(ctx)
	if err != nil {
		log.Fatal("Error connecting to MongoDB:", err)
	}

	err = client.Ping(ctx, nil)
	if err != nil {
		log.Fatal("Could not connect to MongoDB:", err)
	}

	db = client.Database("supplement_shop")
	fmt.Println("Connected to MongoDB successfully")
}

// Enable CORS
func enableCORS(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		// Handle preflight requests
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}

		next.ServeHTTP(w, r)
	})
}

// Create a new item in the collection
func createProductHandler(w http.ResponseWriter, r *http.Request) {
	// Parse incoming JSON body
	var input map[string]interface{}
	err := json.NewDecoder(r.Body).Decode(&input)
	if err != nil {
		respondWithJSON(w, http.StatusBadRequest, map[string]interface{}{
			"status":  "fail",
			"message": "Invalid JSON format",
		})
		return
	}

	// Check if collection name is provided
	collectionName := r.URL.Query().Get("collection")
	if collectionName == "" {
		respondWithJSON(w, http.StatusBadRequest, map[string]interface{}{
			"status":  "fail",
			"message": "Collection name is required",
		})
		return
	}

	// Handle special case for "message"
	if collectionName == "messages" {
		message, ok := input["message"]
		if !ok || message == nil {
			respondWithJSON(w, http.StatusBadRequest, map[string]interface{}{
				"status":  "fail",
				"message": "Invalid JSON message",
			})
			return
		}

		messageStr, isString := message.(string)
		if !isString || messageStr == "" {
			respondWithJSON(w, http.StatusBadRequest, map[string]interface{}{
				"status":  "fail",
				"message": "Invalid JSON message",
			})
			return
		}

		// Log the message to the console
		log.Println("Message received:", messageStr)

		// Insert message into the specified collection
		collection := db.Collection(collectionName)
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()

		input["timestamp"] = time.Now() // Add a timestamp to the message
		_, err = collection.InsertOne(ctx, input)
		if err != nil {
			respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
				"status":  "fail",
				"message": "Failed to save message to the database",
			})
			return
		}

		// Respond with success
		respondWithJSON(w, http.StatusOK, map[string]interface{}{
			"status":  "success",
			"message": "Data successfully received",
		})
		return
	}

	// Handle generic data insertion for other collections
	collection := db.Collection(collectionName)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// Automatically generate an ID if not provided
	if _, hasID := input["_id"]; !hasID {
		input["_id"] = primitive.NewObjectID()
	}

	_, err = collection.InsertOne(ctx, input)
	if err != nil {
		respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"status":  "fail",
			"message": "Failed to save data to the database",
		})
		return
	}

	// Respond with success
	respondWithJSON(w, http.StatusOK, map[string]interface{}{
		"status":  "success",
		"message": "Data successfully saved",
	})
}

// Fetch collection content
func fetchCollectionHandler(w http.ResponseWriter, r *http.Request) {
	// Get the collection name from the query parameter
	collectionName := r.URL.Query().Get("collection")
	if collectionName == "" {
		respondWithJSON(w, http.StatusBadRequest, map[string]interface{}{
			"status":  "fail",
			"message": "Collection name is required",
		})
		return
	}

	// Get the collection from the database
	collection := db.Collection(collectionName)

	// Find all documents in the collection
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	cursor, err := collection.Find(ctx, map[string]interface{}{})
	if err != nil {
		respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"status":  "fail",
			"message": "Failed to fetch data from the collection",
		})
		return
	}
	defer cursor.Close(ctx)

	var results []map[string]interface{}
	for cursor.Next(ctx) {
		var result map[string]interface{}
		if err := cursor.Decode(&result); err != nil {
			respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
				"status":  "fail",
				"message": "Failed to decode data from the collection",
			})
			return
		}
		results = append(results, result)
	}

	// Check for cursor errors
	if err := cursor.Err(); err != nil {
		respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"status":  "fail",
			"message": "Cursor error occurred",
		})
		return
	}

	// Respond with the collection content
	respondWithJSON(w, http.StatusOK, results)
}

// Helper function to send JSON response
func respondWithJSON(w http.ResponseWriter, statusCode int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	if err := json.NewEncoder(w).Encode(payload); err != nil {
		log.Println("Error encoding response:", err)
	}
}

// Main function
func main() {
	connectToMongoDB()

	// Create a new ServeMux and attach the handlers
	mux := http.NewServeMux()
	mux.HandleFunc("/create", createProductHandler)
	mux.HandleFunc("/fetchCollection", fetchCollectionHandler) // Add the new route here

	// Apply CORS middleware to all routes
	log.Println("Server is running on port 8080")
	http.ListenAndServe(":8080", enableCORS(mux))
}
